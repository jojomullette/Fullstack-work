<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pop Vote - A premier Online Destination for Pop Culture Voting</title>
    <link rel="stylesheet" href="/src/App.css" />
</head>
<body>
    <header>
        <div class="container">
            <h1>Pop Vote</h1>
            <nav>
                <ul>
                    <li><a href="index.html">Home</a></li>                    
                    <li><a href="About.html">About</a></li>
               </ul>
            </nav>
        </div>
    </header>

  <section id="hero">
      <div class="taskbar">
        <div class="dropdown">
          <button class="dropbtn">Menu</button>
                        <div class="dropdown-content">
                          <a href="Anime.html">Anime</a>
                          <a href="Marvel.html">Marvel</a>
            </div>
          </div>
        </div>
    
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Sign In</title>
            <link rel="stylesheet" href="styles.css">
        </head>
        <body>
            <div class="container">
                <h2>Sign In</h2>
                <form action="signin.php" method="POST">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit">Sign In</button>
                    <a href="Signup.php">Sign Up</a>
                </form>
            </div>
        </body>

    <footer>
        <div class="container">
            <p>&copy; 2024 Pop Vote. All rights reserved.</p>
        </div>
    </footer>
</body>

</html>

