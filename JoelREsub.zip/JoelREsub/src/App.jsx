import { useState } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import './logo.svg';
import './pages/Home';
import './img/goku.jpg';
import './img/toji.jpeg';
import './img/Ayanokoji.jpg';
import './App.css'

const App = () => {
  const [count, setCount] = useState(0);

  return (
    <>
    <title>Pop Vote - A premier Online Destination for Pop Culture Voting</title>
    <link rel="stylesheet" href="stylesheet.css" />
    <header>
      <div className="container">
        <h1>Pop Vote</h1>
        <nav>
          <ul>
            <li>
              <a href="index.html">Home</a>
            </li>
            <li>
              <a href="About.jsx">About</a>
            </li>
            <li>
              <a href="Signin.php">Sign in</a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
    <section id="hero">
      <div className="taskbar">
        <div className="dropdown">
          <button className="dropbtn">Menu</button>
          <div className="dropdown-content">
            <a href="Anime.html">Anime</a>
            <a href="Marvel.html">Marvel</a>
          </div>
        </div>
      </div>
      <section id="featured">
        <div className="container">
          <h2>Characters</h2>
        </div>
        <button className="image-button">
          <img src="src/img/toji.jpeg" alt="Image 1" />
        </button>
        <button className="image-button">
          <img src="src/img/goku.jpg" alt="Image 2" />
        </button>
        <button className="image-button">
          <img src="src/img/Ayanokoji.jpg" alt="Image 3" />
        </button>
      </section>
      <footer>
        <div className="container">
          <p>© 2024 Pop Vote. All rights reserved.</p>
        </div>
      </footer>
    </section>
  </>  
  );
};

export default App;
